package com.example.HealthcareBooking;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthcareBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthcareBookingApplication.class, args);
	}

}
