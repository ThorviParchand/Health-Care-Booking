package com.example.HealthcareBooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.HealthcareBooking.entity.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {}
