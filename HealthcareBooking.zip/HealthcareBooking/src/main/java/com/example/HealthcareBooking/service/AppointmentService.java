package com.example.HealthcareBooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.HealthcareBooking.entity.Appointment;
import com.example.HealthcareBooking.repository.AppointmentRepository;

@Service
public class AppointmentService {
	 @Autowired
	    private AppointmentRepository appointmentRepository;

	    public List<Appointment> getAllAppointments() {
	        return appointmentRepository.findAll();
	    }

	    public Optional<Appointment> getAppointmentById(Long id) {
	        return appointmentRepository.findById(id);
	    }

	    public Appointment saveAppointment(Appointment appointment) {
	        List<Appointment> existingAppointments = appointmentRepository.findByDoctorIdAndAppointmentTimeBetween(
	            appointment.getDoctor().getId(),
	            appointment.getAppointmentTime().minusMinutes(30),
	            appointment.getAppointmentTime().plusMinutes(30)
	        );

	        if (!existingAppointments.isEmpty()) {
	            throw new RuntimeException("Doctor already has an appointment at this time.");
	        }

	        return appointmentRepository.save(appointment);
	    }

	    public void deleteAppointment(Long id) {
	        appointmentRepository.deleteById(id);
	    }
}
