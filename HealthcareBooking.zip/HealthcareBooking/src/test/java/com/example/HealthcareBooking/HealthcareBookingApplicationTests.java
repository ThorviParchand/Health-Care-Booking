package com.example.HealthcareBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthcareBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
